from queries.querycomponent import QueryComponent
from queries.termliteral import TermLiteral
from queries.orquery import OrQuery
from queries.andquery import AndQuery
from queries.phraseliteral import PhraseLiteral
from queries.booleanqueryparser import BooleanQueryParser
from queries.nearliteral import NearLiteral