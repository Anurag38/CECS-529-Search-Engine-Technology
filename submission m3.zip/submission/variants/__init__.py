from variants.variants import Variants
from variants.defaultvariant import DefaultVariant
