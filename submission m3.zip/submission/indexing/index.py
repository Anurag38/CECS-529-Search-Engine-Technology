from abc import ABC, abstractmethod
from typing import Iterable
from .postings import Posting


class Index(ABC):
    """An Index can retrieve postings for a term from a data structure associating terms and the documents
    that contain them."""

    def getPostings(self, term : str) -> Iterable[Posting]:
        """Retrieves a sequence of Postings of documents that contain the given term."""
        pass

    def getPostingsWithoutPositions(self, term) -> Iterable[Posting]:
        """Retrieves a sequence of Postings of documents that contain the given term without its position."""
        pass

    def getVocabulary(self) -> Iterable[str]:
        """A (sorted) list of all terms in the index vocabulary."""
        pass
