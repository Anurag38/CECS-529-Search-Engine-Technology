from documents.corpus import DocumentCorpus
from documents.directorycorpus import DirectoryCorpus
from documents.textfiledocument import TextFileDocument
from documents.document import Document